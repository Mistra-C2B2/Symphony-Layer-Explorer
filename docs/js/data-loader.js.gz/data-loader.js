/**
 * Data loading and management system for Symphony Layers Explorer
 */

class DataLoader {
    constructor() {
        this.data = {
            symphonyLayers: null,
            referenceParameters: null,
            recommendationParameters: null,
            catalogue: null
        };
        this.loaded = false;
        this.loading = false;
    }

    async loadAll() {
        if (this.loading) return;
        if (this.loaded) return this.data;
        
        this.loading = true;
        
        try {
            console.log('Loading Symphony data...');
            
            // Load all JSON files in parallel
            const [symphonyLayers, referenceParameters, recommendationParameters, catalogue] = await Promise.all([
                this.fetchJSON('data/symphony_layers.json'),
                this.fetchJSON('data/reference_parameters.json'),
                this.fetchJSON('data/recommendation_parameters.json'),
                this.fetchJSON('data/catalogue.json')
            ]);

            this.data.symphonyLayers = symphonyLayers;
            this.data.referenceParameters = referenceParameters;
            this.data.recommendationParameters = recommendationParameters;
            this.data.catalogue = catalogue;

            // Create cross-reference indexes
            this.createIndexes();
            
            this.loaded = true;
            console.log('All data loaded successfully');
            
            return this.data;
            
        } catch (error) {
            console.error('Failed to load data:', error);
            throw new Error(`Failed to load application data: ${error.message}`);
        } finally {
            this.loading = false;
        }
    }

    async fetchJSON(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            console.log(`Loaded ${url}: ${Array.isArray(data) ? data.length : Object.keys(data).length} items`);
            return data;
        } catch (error) {
            console.error(`Failed to fetch ${url}:`, error);
            throw error;
        }
    }

    createIndexes() {
        // Create indexes for faster lookups
        console.log('Creating data indexes...');
        
        // Index symphony layers by title
        this.symphonyLayersByTitle = {};
        this.data.symphonyLayers.forEach(layer => {
            this.symphonyLayersByTitle[layer.title.toLowerCase()] = layer;
        });

        // Index reference parameters by ID
        this.referenceParametersById = {};
        this.data.referenceParameters.forEach(param => {
            this.referenceParametersById[param.id] = param;
        });

        // Index catalogue by parameter ID and name
        this.catalogueByParameterId = {};
        this.catalogueByParameterName = {};
        
        this.data.catalogue.forEach(dataset => {
            if (dataset.p02_parameters && Array.isArray(dataset.p02_parameters)) {
                dataset.p02_parameters.forEach(paramName => {
                    // Index by parameter name
                    const paramNameLower = paramName.toLowerCase();
                    if (!this.catalogueByParameterName[paramNameLower]) {
                        this.catalogueByParameterName[paramNameLower] = [];
                    }
                    this.catalogueByParameterName[paramNameLower].push(dataset);
                    
                    // Also try to find matching parameter ID
                    const matchingParam = this.data.referenceParameters.find(p => 
                        p.preferred_label.toLowerCase() === paramNameLower
                    );
                    if (matchingParam) {
                        if (!this.catalogueByParameterId[matchingParam.id]) {
                            this.catalogueByParameterId[matchingParam.id] = [];
                        }
                        this.catalogueByParameterId[matchingParam.id].push(dataset);
                    }
                });
            }
        });

        // Group symphony layers by category
        this.layersByCategory = {
            'Ecosystem': [],
            'Pressure': [],
            'Source Data': []
        };

        this.data.symphonyLayers.forEach(layer => {
            // Map layer categories (assuming they exist in the original data)
            // This might need adjustment based on actual data structure
            const category = this.inferCategory(layer.title);
            if (this.layersByCategory[category]) {
                this.layersByCategory[category].push(layer);
            }
        });

        console.log('Indexes created successfully');
        console.log('Layers by category:', Object.keys(this.layersByCategory).map(cat => 
            `${cat}: ${this.layersByCategory[cat].length}`).join(', '));
    }

    inferCategory(title) {
        // This is a simplified categorization - in a real implementation,
        // you'd want to have this information in your data
        const ecosystemKeywords = ['birds', 'fish', 'mammals', 'plants', 'habitat', 'reef', 'cod', 'herring', 'seal'];
        const pressureKeywords = ['climate', 'pollution', 'fishing', 'shipping', 'noise', 'extraction', 'farm'];
        
        const titleLower = title.toLowerCase();
        
        if (ecosystemKeywords.some(keyword => titleLower.includes(keyword))) {
            return 'Ecosystem';
        } else if (pressureKeywords.some(keyword => titleLower.includes(keyword))) {
            return 'Pressure';
        } else {
            return 'Source Data';
        }
    }

    // Getter methods for easy access
    getSymphonyLayers() {
        return this.data.symphonyLayers || [];
    }

    getLayersByCategory(category) {
        return this.layersByCategory[category] || [];
    }

    getLayerByTitle(title) {
        return this.symphonyLayersByTitle[title.toLowerCase()];
    }

    getReferenceParameters() {
        return this.data.referenceParameters || [];
    }

    getParameterById(id) {
        return this.referenceParametersById[id];
    }

    getRecommendationParameters() {
        return this.data.recommendationParameters || {};
    }

    getParameterIdsForTitle(title) {
        return this.data.recommendationParameters[title.toLowerCase()] || [];
    }

    getCatalogue() {
        return this.data.catalogue || [];
    }

    getDatasetsByParameterId(paramId) {
        return this.catalogueByParameterId[paramId] || [];
    }

    getDatasetsByParameterName(paramName) {
        return this.catalogueByParameterName[paramName.toLowerCase()] || [];
    }

    getDatasetsByParameterIds(paramIds) {
        const datasets = new Map();
        
        paramIds.forEach(paramId => {
            const paramDatasets = this.getDatasetsByParameterId(paramId);
            paramDatasets.forEach(dataset => {
                datasets.set(dataset.id_dataset, dataset);
            });
        });
        
        return Array.from(datasets.values());
    }

    // Search functionality
    searchParameters(query) {
        if (!query) return this.getReferenceParameters();
        
        const queryLower = query.toLowerCase();
        return this.getReferenceParameters().filter(param => 
            param.preferred_label.toLowerCase().includes(queryLower) ||
            (param.definition && param.definition.toLowerCase().includes(queryLower)) ||
            param.id.toLowerCase().includes(queryLower)
        );
    }

    searchDatasets(query) {
        if (!query) return this.getCatalogue();
        
        const queryLower = query.toLowerCase();
        return this.getCatalogue().filter(dataset => 
            (dataset.name && dataset.name.toLowerCase().includes(queryLower)) ||
            (dataset.source && dataset.source.toLowerCase().includes(queryLower)) ||
            (dataset.regions && dataset.regions.some(region => region.includes(queryLower)))
        );
    }

    // Data validation
    validate() {
        const required = ['symphonyLayers', 'referenceParameters', 'recommendationParameters', 'catalogue'];
        const missing = required.filter(key => !this.data[key]);
        
        if (missing.length > 0) {
            throw new Error(`Missing required data: ${missing.join(', ')}`);
        }

        // Validate data integrity
        const symphonyCount = this.data.symphonyLayers.length;
        const paramCount = this.data.referenceParameters.length;
        const catalogueCount = this.data.catalogue.length;
        
        console.log(`Data validation: ${symphonyCount} layers, ${paramCount} parameters, ${catalogueCount} datasets`);
        
        if (symphonyCount === 0 || paramCount === 0 || catalogueCount === 0) {
            throw new Error('Data files appear to be empty');
        }

        return true;
    }
}

// Create global data loader instance
window.dataLoader = new DataLoader();