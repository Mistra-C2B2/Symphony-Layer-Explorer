/**
 * Chart creation and management for Symphony Wheels
 */

class SymphonyCharts {
    constructor() {
        this.chart = null;
        this.canvas = null;
        this.currentCategory = null;
        
        // Color scheme for different themes
        this.colorMap = {
            'Birds': "#5b9bd5",
            'Fish': "#ed7d31", 
            'Fish function': '#a5a5a5',
            'Habitat': '#ffc000',
            'Marine Mammals': '#4472c4',
            'Plants': '#70ad47',
            'Aquaculture': '#5b9bd5',
            'Climate Change': '#ed7d31',
            'Coastal Development': '#a5a5a5', 
            'Defence': '#ffc000',
            'Energy': '#4472c4',
            'Eutrophication': '#70ad47',
            'Fishing': '#255e91',
            'General Pollution': '#9e480e',
            'Industry': '#636363',
            'Mineral Mining': '#997300',
            'Recreation': '#264478',
            'Shipping': '#43682b',
            // Default colors for layers
            'Default': '#667eea',
            'Ecosystem': '#5b9bd5',
            'Pressure': '#ed7d31',
            'Source Data': '#70ad47'
        };

        this.onLayerClick = null; // Callback for layer selection
    }

    init() {
        this.canvas = document.getElementById('symphony-chart');
        if (!this.canvas) {
            console.error('Chart canvas not found');
            return false;
        }
        return true;
    }

    createWheel(category, layers) {
        if (!this.canvas) return;
        
        this.currentCategory = category;
        
        // Destroy existing chart
        if (this.chart) {
            this.chart.destroy();
        }

        // Group layers by theme (simplified - in reality you'd have theme data)
        const groupedLayers = this.groupLayersByTheme(layers);
        
        // Prepare data for nested donut chart
        const chartData = this.prepareChartData(groupedLayers);
        
        // Create the chart
        this.chart = new Chart(this.canvas.getContext('2d'), {
            type: 'doughnut',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            generateLabels: function(chart) {
                                // Custom legend to show themes
                                const themes = Object.keys(groupedLayers);
                                return themes.map((theme, index) => ({
                                    text: theme,
                                    fillStyle: chart.data.datasets[0].backgroundColor[themes.indexOf(theme)] || '#667eea',
                                    strokeStyle: '#fff',
                                    lineWidth: 1,
                                    hidden: false,
                                    index: index
                                }));
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const layer = layers[context.dataIndex];
                                if (layer) {
                                    return `${layer.title}: ${layer.valuability}`;
                                }
                                return context.label;
                            },
                            afterLabel: (context) => {
                                const layer = layers[context.dataIndex];
                                if (layer && layer.data_availability_index) {
                                    return `Data Availability: ${layer.data_availability_index}%`;
                                }
                                return '';
                            }
                        }
                    }
                },
                onClick: (event, elements) => {
                    if (elements.length > 0) {
                        const clickedIndex = elements[0].index;
                        const clickedLayer = layers[clickedIndex];
                        if (clickedLayer && this.onLayerClick) {
                            this.onLayerClick(clickedLayer);
                        }
                    }
                },
                onHover: (event, elements) => {
                    event.native.target.style.cursor = elements.length > 0 ? 'pointer' : 'default';
                }
            }
        });
    }

    groupLayersByTheme(layers) {
        // Simplified grouping - in reality you'd have theme information in your data
        const themes = {};
        
        layers.forEach(layer => {
            const theme = this.inferTheme(layer.title, this.currentCategory);
            if (!themes[theme]) {
                themes[theme] = [];
            }
            themes[theme].push(layer);
        });

        return themes;
    }

    inferTheme(title, category) {
        // Simplified theme inference based on keywords
        const titleLower = title.toLowerCase();
        
        if (category === 'Ecosystem') {
            if (titleLower.includes('bird')) return 'Birds';
            if (titleLower.includes('fish') || titleLower.includes('cod') || titleLower.includes('herring')) return 'Fish';
            if (titleLower.includes('seal') || titleLower.includes('mammal') || titleLower.includes('porpoise')) return 'Marine Mammals';
            if (titleLower.includes('plant') || titleLower.includes('angiosperm')) return 'Plants';
            if (titleLower.includes('habitat') || titleLower.includes('reef') || titleLower.includes('bottom')) return 'Habitat';
            return 'Other Ecosystem';
        } else if (category === 'Pressure') {
            if (titleLower.includes('climate') || titleLower.includes('temperature') || titleLower.includes('acidification')) return 'Climate Change';
            if (titleLower.includes('fish') && (titleLower.includes('catch') || titleLower.includes('trawl'))) return 'Fishing';
            if (titleLower.includes('ship')) return 'Shipping';
            if (titleLower.includes('pollution') || titleLower.includes('toxic') || titleLower.includes('metal')) return 'General Pollution';
            if (titleLower.includes('noise') || titleLower.includes('sound')) return 'Noise';
            if (titleLower.includes('energy') || titleLower.includes('wind')) return 'Energy';
            if (titleLower.includes('aquaculture') || titleLower.includes('farm')) return 'Aquaculture';
            return 'Other Pressure';
        }
        
        return 'Miscellaneous';
    }

    prepareChartData(groupedLayers) {
        const labels = [];
        const data = [];
        const backgroundColor = [];
        const borderColor = [];
        
        Object.keys(groupedLayers).forEach(theme => {
            groupedLayers[theme].forEach(layer => {
                labels.push(this.formatLayerLabel(layer.title));
                data.push(1); // Equal size for each segment
                
                // Get color for the theme
                const color = this.colorMap[theme] || this.colorMap['Default'];
                backgroundColor.push(color);
                borderColor.push('#ffffff');
            });
        });

        return {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: backgroundColor,
                borderColor: borderColor,
                borderWidth: 2,
                hoverBorderWidth: 3,
                hoverOffset: 4
            }]
        };
    }

    formatLayerLabel(title) {
        // Format long titles for better display
        if (title.length > 20) {
            const words = title.split(' ');
            if (words.length > 2) {
                const midpoint = Math.ceil(words.length / 2);
                return words.slice(0, midpoint).join(' ') + '\n' + words.slice(midpoint).join(' ');
            }
        }
        return title;
    }

    destroy() {
        if (this.chart) {
            this.chart.destroy();
            this.chart = null;
        }
    }

    // Set callback for layer clicks
    setLayerClickHandler(callback) {
        this.onLayerClick = callback;
    }
}

// Create global charts instance
window.symphonyCharts = new SymphonyCharts();